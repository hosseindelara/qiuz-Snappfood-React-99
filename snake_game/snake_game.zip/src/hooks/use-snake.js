 export default function useSnake() {
   // your code here
 }
